
<?php
$host = "localhost";  
$username = "root";  
$password = "";  // Ensure this is correct (empty for XAMPP by default)
$database = "user_db";  

$conn=mysqli_connect($servername,$username,$password,$database);

if(!$conn){
    die("failed to connect" . mysqli_connect_error());
}
echo "SUCCESSFULLY CONNECTED";



if (isset($_POST['register'])) {
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $sql = "INSERT INTO users (username, password) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    echo "Registration successful!";
}

if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $sql = "SELECT * FROM users WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            $_SESSION['username'] = $username;
            echo "Login successful!";
        } else {
            echo "Invalid password!";
        }
    } else {
        echo "User not found!";
    }
}

if (isset($_GET['logout'])) {
    session_destroy();
    echo "Logged out successfully!";
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin login</title>
<!-- UIkit CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/uikit@3.21.13/dist/css/uikit.min.css" />
<link rel="stylesheet" href="Admin.css">
</head>
<body>
    <body>
        <div class="container">
            <h2>Admin Login</h2>
            <form action="Admin.php" method="POST">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required>
                
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
                <a href="forgot_password.php">Forgot Password?</a>
                <br>
                <button type="submit">Login</button>
                
            </form>

    <a href="Register">Register</a>
    <br>
    <a href="Logout">Logout</a>

    </div>
<!-- UIkit JS -->
<script src="https://cdn.jsdelivr.net/npm/uikit@3.21.13/dist/js/uikit.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/uikit@3.21.13/dist/js/uikit-icons.min.js"></script>

</body>
</html>
