<?php
     include 'Conn.php';

     $id = $_GET['id'];

     $sql = "SELECT * FROM appointments WHERE id=$id";
     
     $results = mysqli_query($conn, $query);
     

     if ($results == mysqli_query($conn, $query)) { }
     $results = mysqli_query($conn, $query);

    if(mysqli_num_rows($results)>0){
        while($row = mysqli_fetch_assoc($results)){
            $Id['Id'];
            $Id['Patient Id'];
            $Name['Patient Name'];
            $cont['Contact'];
            $Add['Address'];
            $Id['Doctor Id'];
            $Apdate['Appointment date'];
            $Aptime['Appointment time'];
            $Reason['Reason'];
        }
    }
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ABC Virtual Hospital</title>
</head>
<body>
<form action="" method="POST">
Id
        <input type="text" name="txt-id"value="<?php echo $name?>"Id=""><br>
        Patient Id
        <input type="text" name="txt-id"value="<?php echo $name?>"Id=""><br>
        Patient Name
        <input type="text" name="txt-name"value="<?php echo $name?>"Id=""><br>
        Contact
        <input type="text" name="txt-Contact"value="<?php echo $name?>"Id=""><br>
        Address
        <input type="text" name="txt-Address"value="<?php echo $name?>"Id=""><br>
        Doctor Id
        <input type="text" name="txt-Id"value="<?php echo $name?>"Id=""><br>
        Appointment date
        <input type="text" name="txt-date"value="<?php echo $name?>"Id=""><br>
        Appointment time
        <input type="text" name="txt-time"value="<?php echo $name?>"Id=""><br>
        Reason
        <input type="text" name="txt-Text"value="<?php echo $name?>"Id=""><br>

        <input type="submit" name="btn-edit" value="edit patient">
    </form>

    <?php
    if(isset($_POST['btn-edit'])){
        $Id = $_POST['txt-Id'];
        $Name = $_POST['txt-Name'];
        $Cont = $_POST['txt-Cont'];
        $Address =  $_POST['txt-Address'];
        $Id = $_POST['txt-Id'];
        $Apdate = $_POST['txt-date'];
        $Aptime = $_POST['txt-time'];
        $Reason =  $_POST['txt-Reason'];

        $edit = "UPDATE `appointments` SET `name`='$name', `contact`='$cont',`Address`='$add', `Doctor Id`='$Id',`Appointment date='$apdate``Appointment time`='$Aptime',
         `Reason`='$Reason WHERE `Id`='$Id'";

        if(mysqli_query($conn, $edit)){
            header("Location:view_app1.php");
        }
        else{
            echo "error" . $sqledit . "<br>". mysqli_error($conn);
        }
    }

?>


</body>
</html>