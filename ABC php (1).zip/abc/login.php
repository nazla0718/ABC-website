<?php
session_start();
include 'user_db'; // Connect to MySQL

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['username'];
    $password = md5($_POST['password']); // Encrypt password (MD5 used for simplicity)

    // Check user role
    $query = "SELECT * FROM user WHERE user_name='$user_name' AND password='$password'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) == 1) {
        $user = mysqli_fetch_assoc($result);
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['name'];
        $_SESSION['password'] = $user['password'];

        // Redirect based on role
        if ($user['role'] == 'admin') {
            header("Location: user.php");
        } elseif ($user['role'] == 'doctor') {
            header("Location: user.php");
        } elseif ($user['role'] == 'receptionist') {
            header("Location: receptionist_dashboard.php");
        }
        exit();
    } else {
        $error = "Invalid user_name or password!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - ABC Virtual Hospital</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/uikit@3.7.3/dist/css/uikit.min.css">
    <script src="https://cdn.jsdelivr.net/npm/uikit@3.7.3/dist/js/uikit.min.js"></script>
</head>
<body>
    <div class="uk-container uk-margin-large-top uk-width-1-3@m">
        <h2 class="uk-text-center">🔐 Login</h2>

        <?php if(isset($error)) echo "<p class='uk-alert-danger'>$error</p>"; ?>

        <form method="post">
            <div class="uk-margin">
                <label>username</label>
                <input type="user_name" name="user_name" class="uk-input" required>
            </div>
            <div class="uk-margin">
                <label>Password</label>
                <input type="password" name="password" class="uk-input" required>
            </div>
            <button type="submit" class="uk-button uk-button-primary uk-width-1-1">Login</button>
        </form>
    </div>
</body>
</html>
