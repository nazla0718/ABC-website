<?php
     include 'conn.php';

     if(isset($_POST["btn-add"])){
        $id = $_POST['txt-id'];
        $name = $_POST['txt-name'];
        $cont = $_POST['txt-cont'];
        $dis = $_POST['txt-dis'];
        $guard = $_POST['txt-guard'];

        $add = "INSERT INTO `abc virtual` (`Id`, `Patient Id`, `Patient Name`, `Contact`, `Address`, `Doctor Id`,'Appointment date','Appointment time','Reason') VALUES('$Id', '$PId', '$PName', '$cont', '$Add', '$DId',$Apdate,$Aptime,$Reason)";
        
        if(mysqli_query($conn, $add)){
            echo "successfully patient added";
        }
        else{
            echo "error" . $add . "<br>" . mysqli_error($conn);
        }
    }
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ABC Virtual Hospital</title>
</head>
<body>
    <form action="" method="POST">
        Id
        <input type="text" name="txt-id"><br>
        Patient Id
        <input type="text" name="txt-id" id=""><br>
        Patient Name
        <input type="text" name="txt-name"><br>
        Contact
        <input type="text" name="txt-Contact"><br>
        Address
        <input type="text" name="txt-Address"><br>
        Doctor Id
        <input type="text" name="txt-Id"><br>
        Appointment date
        <input type="text" name="txt-date"><br>
        Appointment
        <input type="text" name="txt-time"><br>
        Reason
        <input type="text" name="txt-Text"><br>

        <input type="submit" name="btn-add" value="add patient">
    </form>
</body>
</html>