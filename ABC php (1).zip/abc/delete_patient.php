<?php
            include 'Conn.php';

            $id = $_GET['Id'];
            
            $sqldel = "DELETE FROM Appointments WHERE Id=$Id" ;

            if(mysqli_query($conn, $sqldel)){
                header("Location: view_app1.php");
            }else{
                echo "error" . mysqli_error($conn);
            }
        
?>