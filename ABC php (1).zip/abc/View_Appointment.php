<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ABC Virtual Hospital</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/uikit@3.21.16/dist/css/uikit.min.css" />

<!-- UIkit JS -->
<script src="https://cdn.jsdelivr.net/npm/uikit@3.21.16/dist/js/uikit.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/uikit@3.21.16/dist/js/uikit-icons.min.js"></script>
</head>
<body>
    <?php
        include 'conn.php';

        $viewsql = "SELECT * FROM Appointments"; 
        $results = mysqli_query($conn, $viewsql);
    ?>

    <table  class="uk-table uk-table-hover uk-table-divider">
        <thead>
            <tr>
                <th>Id</th>
                <th>Patient Id</th>
                <th>Patient Name</th>
                <th>Contact</th>
                <th>Address</th>
                <th>Doctor Id</th>
                <th>Appointment Date</th>
                <th>Appointment time</th>     
                <th>Reasons</th>
        </thead>
        <tbody>
        <?php if(mysqli_num_rows($results)>0){
                    while($row=mysqli_fetch_assoc($results)){
                        echo "<tr>
                            <td>".$row['Id']."</td>
                            <td>".$row['Patient Id']."</td>
                            <td>".$row['Patient Name']."</td>
                            <td>".$row['Contact']."</td>
                            <td>".$row['Address']."</td>
                            <td>".$row['Doctor Id']."</td>
                            <td>".$row['Appointment date']."</td>
                            <td>".$row['Appointment time']."</td>
                            <td>".$row['Reason']."</td>
                        </tr>";
                        
                    }
                }
        ?>
        </tbody>
    </table>
    <a href="doctor_dashboard.php" class="uk-button uk-button-secondary">Back</a>
</body>
</html>